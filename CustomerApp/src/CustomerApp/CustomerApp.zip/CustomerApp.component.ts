import { Component } from '@angular/core';
import { Customer } from './CustomerApp.model'

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './CustomerApp.view.html',
  // styleUrl: './app.component.css'
})
export class CustomerComponent {
  title = 'CustomerApp';
  CustomerModel : Customer = new Customer();
}
